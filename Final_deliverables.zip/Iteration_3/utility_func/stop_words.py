# -*- coding: utf-8 -*-
"""
Created on Sun Mar 05 10:04:12 2017

@author: anbarasan.selvarasu
"""

emp_name = ['albert','meyers','thomas','martin','andrea','ring','andrew','lewis','andy'
            ,'zipper','jeffrey','shankman','barry','tycholiz','benjamin','rogers','bill'
            ,'rapp','bradley','mckay','richard','sanders','cara','semperger','daron'
            ,'giron','charles','weldon','chris','dorland','chris','germany','cooper'
            ,'richey','craig','dean','dana','davis','dan','hyvl','danny','mccarty','daren'
            ,'farmer','daron','giron','david','delainey','susan','bailey','e','xxx','diana','scholtes','thomas','martin','don','baughman','drew','fossum','james','steffes','mark','haedicke','elizabeth','sager','eric','bass','eric','saibi','errol','mclau','mark','taylor','sandra','brawner','larry','campbell','peter','keavey','fletcher','sturm','frank','ermis','geir'
            ,'solberg','geoffery','storey','gerald','nemec','greg','whalley','xxx','','harpreet'
            ,'arora','andrew','lewis','holden','sali','hunter','shively','james','derrick','james','steffes','jane','tholt','xxx','','jason','wolfe','jay','reitmeyer','jeff','dasovich','jeff','king','john','hodge','jeffrey','sha','jeffery','skilling','daren','farmer','jim','schwieger','vince','kaminski','vince','kaminski','ean','vice','on','xxx','joe','parks','joe','quenet','joe','stepeno','john','arnold','john','forney','john','hodge','john','lavorato','john','zufferli','jonathan','mckay','fletcher','sturm','juan','hernandez','xxx','','judy','townsend','philip','allen','kam','keiser','kate','symes','kay','mann','keith','holst','kenneth'
            ,'lay','kevin','hyatt','kevin','presto','kevin','ruscitti','kimberly','watson','kim','ward','larry','campbell','lawrence','may','gay','n/a','lindy','donoho','mims','n/a','louise','kitchen','lynn','blair','marie','heard','mark','haedicke','mark','haedicke','mark','taylor','mark','whitt','martin','cuilla','mary','fischer','matthew','lenhart','matthew','motley','john','forney','michelle','lokay','michelle','cash','michelle','lokay','mike','carson','michael','grigsby','michael','maggi','mike','swerzbin','love','n/a','monika','caus','xxx','','kevin','presto','susan','scott','jane','tholt','patrice','mims','paul','thomas','peter','keavey','philip','allen','phillip','love','phillip','platter','randall','gay','richard','ring','richard'
            ,'sanders','richard','shapiro','rick','buy','robert','badeer','robert','benson'
            ,'rod','hayslett','ryan','slinger','sally','beck','sandra','brawner','scott','neal'
            ,'shelley','corman','hunter','shively','stacy','dickson','stanley','horton','stephanie'
            ,'panus','steven','kean','susan','bailey','susan','pereira','susan','scott','tana'
            ,'jones','teb','lokey','theresa','staab','john','hodge','thomas','martin','paul','lucci'
            ,'tom','donohoe','tori','kuykendall','tracy','geaccone','vince','kaminski','vladi'
            ,'pimenov','charles','weldon','david','delainey','susan','pereira','stacey','white']

months = ['january','february','march', 'april', 'may', 'june','july','august','september','october','november','december'
           ,'am','pm','gmt']
           
salutations = ['hello','hi','thankyou','thanks','regards','dear','warm','welcome']
web_reltd = ['http','img','html',]
misc =  ['mr', 'mrs', 'come', 'go', 'get',
                 'tell', 'listen', 'one', 'two', 'three',
                 'four', 'five', 'six', 'seven', 'eight',
                 'nine', 'zero', 'join', 'find', 'make',
                 'say', 'ask', 'tell', 'see', 'try', 'back',
                 'also']
                 
custom_stopwords = emp_name + months + salutations + misc