# -*- coding: utf-8 -*-
"""
Created on Fri Mar 03 08:24:57 2017

@author: anbarasan.selvarasu
"""

class utils(object):
    
    def __init__(self):
        pass
    
    

   
    
        
        